package com.example.myintent

data class Hero(
    var name: String = "",
    var from: String = "",
    var photo: String = ""
)
