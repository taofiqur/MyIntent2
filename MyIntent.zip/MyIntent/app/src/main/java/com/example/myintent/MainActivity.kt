package com.example.myintent

import android.app.Person
import android.content.Intent
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.provider.Telephony.Mms.Intents
import android.view.View
import android.widget.Button
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts

class MainActivity : AppCompatActivity(), View.OnClickListener{
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val btnMoveActivity: Button =
            findViewById(R.id.btn_move_activity)
        btnMoveActivity.setOnClickListener(this)

        val btnMoveWhitDataActivity : Button =
            findViewById(R.id.btn_move_with_data)
        btnMoveWhitDataActivity.setOnClickListener(this)

        val btnDialPhone: Button =
            findViewById(R.id.btn_dial_number)
        btnDialPhone.setOnClickListener(this)

        val btnMoveWhitObjectActivity: Button =
            findViewById(R.id.btn_move_with_object)
        btnMoveWhitObjectActivity.setOnClickListener(this)

        val btnMoveWhitResultActivity: Button =
            findViewById(R.id.btn_move_with_result)
        btnMoveWhitResultActivity.setOnClickListener(this)
    }

    override fun onClick(v: View) {
        when (v.id) {
            R.id.btn_move_activity -> {
                val moveIntent = Intent(this@MainActivity, MoveActivity::class.java)
                startActivity(moveIntent)
            }
            R.id.btn_move_with_data -> {
                val moveWithDataIntent = Intent(
                    this@MainActivity, MoveWithDataActivity
                    ::class.java
                )

                moveWithDataIntent.putExtra(MoveWithDataActivity.EXTRA_NAME, "SAM")
                moveWithDataIntent.putExtra(MoveWithDataActivity.EXTRA_AGE, 5)
                startActivity(moveWithDataIntent)
            }
            R.id.btn_dial_number -> {
                val phoneNumber = "085785455235"

                val dialPhoneIntent = Intent(Intent.ACTION_DIAL, Uri.parse("tel: $phoneNumber"))
                startActivity(dialPhoneIntent)
            }
            R.id.btn_move_with_object -> {
                val person = Person("Piqur", "piqurreal@gmail.com", "malang")
                val moveWhitObjectIntent = Intent(
                    this@MainActivity, MoveWithObjectActivity
                    ::class.java
                )

                moveWhitObjectIntent.putExtra(MoveWithObjectActivity.EXTRA_PERSON, person)
                startActivity(moveWhitObjectIntent)
            }
            R.id.btn_move_with_result -> {
                val moveWhitResultIntent = Intent(
                    this@MainActivity, MoveWithResultActivity
                    ::class.java
                )

                startActivity(moveWhitResultIntent)
            }
        }

    }
}